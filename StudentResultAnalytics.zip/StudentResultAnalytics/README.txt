STUDENT RESULT ANALYTICS DASHBOARD
===================================

Files:
- index.html: dashboard page
- style.css: layout and styling
- script.js: interactive dashboard with sample data
- database.sql: MySQL schema, sample records, and analytics queries

HOW TO RUN
1. Extract the ZIP file.
2. Open index.html in a web browser.
3. Open MySQL Workbench and run database.sql to create the database and view the SQL analytics.

IMPORTANT
The browser dashboard uses sample data in script.js. The MySQL database is separate and is not directly connected to the webpage. A server-side connector would be required for live browser-to-MySQL communication.
