-- Student Result Analytics database
CREATE DATABASE IF NOT EXISTS student_analytics;
USE student_analytics;

CREATE TABLE students (
  student_id INT PRIMARY KEY,
  student_name VARCHAR(100) NOT NULL,
  class_name VARCHAR(30)
);

CREATE TABLE marks (
  mark_id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  subject_name VARCHAR(50) NOT NULL,
  marks_obtained INT NOT NULL CHECK (marks_obtained BETWEEN 0 AND 100),
  FOREIGN KEY (student_id) REFERENCES students(student_id)
);

INSERT INTO students (student_id, student_name, class_name) VALUES
(1, 'Aarav', 'MCA-AIML'),
(2, 'Priya', 'MCA-AIML'),
(3, 'Rahul', 'MCA-AIML'),
(4, 'Simran', 'MCA-AIML'),
(5, 'Neha', 'MCA-AIML');

INSERT INTO marks (student_id, subject_name, marks_obtained) VALUES
(1, 'Python', 85), (1, 'SQL', 78), (1, 'Data Analytics', 90),
(2, 'Python', 92), (2, 'SQL', 88), (2, 'Data Analytics', 95),
(3, 'Python', 55), (3, 'SQL', 60), (3, 'Data Analytics', 58),
(4, 'Python', 35), (4, 'SQL', 42), (4, 'Data Analytics', 38),
(5, 'Python', 80), (5, 'SQL', 75), (5, 'Data Analytics', 82);

-- 1. Total students
SELECT COUNT(*) AS total_students FROM students;

-- 2. Subject-wise average marks
SELECT subject_name, ROUND(AVG(marks_obtained), 2) AS average_marks
FROM marks GROUP BY subject_name;

-- 3. Student-wise total marks and percentage
SELECT s.student_name, SUM(m.marks_obtained) AS total_marks,
       ROUND(AVG(m.marks_obtained), 2) AS percentage
FROM students s JOIN marks m ON s.student_id = m.student_id
GROUP BY s.student_id, s.student_name;

-- 4. Topper
SELECT s.student_name, ROUND(AVG(m.marks_obtained), 2) AS percentage
FROM students s JOIN marks m ON s.student_id = m.student_id
GROUP BY s.student_id, s.student_name
ORDER BY percentage DESC LIMIT 1;

-- 5. Pass/fail status (pass requires at least 40 in every subject)
SELECT s.student_name,
       CASE WHEN MIN(m.marks_obtained) >= 40 THEN 'Pass' ELSE 'Fail' END AS result
FROM students s JOIN marks m ON s.student_id = m.student_id
GROUP BY s.student_id, s.student_name;

-- 6. Overall pass percentage
SELECT ROUND(
  100.0 * SUM(CASE WHEN result = 'Pass' THEN 1 ELSE 0 END) / COUNT(*), 2
) AS pass_percentage
FROM (
  SELECT s.student_id,
         CASE WHEN MIN(m.marks_obtained) >= 40 THEN 'Pass' ELSE 'Fail' END AS result
  FROM students s JOIN marks m ON s.student_id = m.student_id
  GROUP BY s.student_id
) AS student_results;
