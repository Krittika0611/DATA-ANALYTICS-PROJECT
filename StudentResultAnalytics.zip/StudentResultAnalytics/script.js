// Demo data for the browser dashboard. The MySQL database is managed separately via database.sql.
const students = [
  { id: 1, name: "Aarav", python: 85, sql: 78, analytics: 90 },
  { id: 2, name: "Priya", python: 92, sql: 88, analytics: 95 },
  { id: 3, name: "Rahul", python: 55, sql: 60, analytics: 58 },
  { id: 4, name: "Simran", python: 35, sql: 42, analytics: 38 },
  { id: 5, name: "Neha", python: 80, sql: 75, analytics: 82 }
];
const subjects = ["python", "sql", "analytics"];

students.forEach(student => {
  student.total = subjects.reduce((sum, subject) => sum + student[subject], 0);
  student.percentage = student.total / subjects.length;
  student.result = subjects.every(subject => student[subject] >= 40) ? "Pass" : "Fail";
});

document.getElementById("total").textContent = students.length;
const average = students.reduce((sum, student) => sum + student.percentage, 0) / students.length;
document.getElementById("average").textContent = average.toFixed(1) + "%";
const passCount = students.filter(student => student.result === "Pass").length;
document.getElementById("pass").textContent = (passCount / students.length * 100).toFixed(0) + "%";

function renderStudents(query = "") {
  const filtered = students.filter(student => student.name.toLowerCase().includes(query.toLowerCase()));
  document.getElementById("studentTable").innerHTML = filtered.map(student => `
    <tr>
      <td>${student.id}</td><td>${student.name}</td><td>${student.python}</td>
      <td>${student.sql}</td><td>${student.analytics}</td><td>${student.total}</td>
      <td class="${student.result === "Pass" ? "pass" : "fail"}">${student.result}</td>
    </tr>`).join("");
}
document.getElementById("search").addEventListener("input", event => renderStudents(event.target.value));

function renderChart() {
  const chart = document.getElementById("chart");
  chart.innerHTML = subjects.map(subject => {
    const avg = students.reduce((sum, student) => sum + student[subject], 0) / students.length;
    const label = subject === "sql" ? "SQL" : subject === "analytics" ? "Data Analytics" : "Python";
    return `<div class="bar-row"><strong>${label}</strong> <span>${avg.toFixed(1)} / 100</span>
      <div class="bar-track"><div class="bar" style="width:${avg}%"></div></div></div>`;
  }).join("");
}
renderStudents();
renderChart();
